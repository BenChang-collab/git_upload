package com.midterm.service.impl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.midterm.service.MidtermService;

@Service
public class MidtermServiceImpl implements MidtermService {
	private static final String QUERY = "select A.* from ( select * from STUDENT.EX_WORDLE order by dbms_random.value) A where rownum <= ?";

	@Autowired
	private DataSource dataSource;

	/**
	 * 第四題：對對碰
	 * 在Java只處理向db撈資料並整理資料動作
	 * @param map
	 * @return
	 */
	@Override
	public Map<String, Object> matchingGame(Map<String, String> map) {
		String strNum = map.get("num");
		int num = Integer.parseInt(strNum);
		num = (num * num) / 2;
		List<Map<String, String>> numlist = new ArrayList<>();
		try (Connection conn = dataSource.getConnection(); PreparedStatement pstmt = conn.prepareStatement(QUERY);) {
			pstmt.setInt(1, num);
			ResultSet rs = pstmt.executeQuery();
			while (rs.next()) {
				Map<String, String> numMap = new HashMap<>();
				numMap.put("vocabulary", rs.getString("VOCAB"));
				numlist.add(numMap);
			}
			rs.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		Map<String, Object> resultMap = new HashMap<>();
		List<String> vocabularies = new ArrayList<>();
		for (Map<String, String> list : numlist) {
			vocabularies.add(list.get("vocabulary"));
		}
		resultMap.put("vocabularies", vocabularies);
		return resultMap;
	}

	/**
	 * 範例程式
	 * 
	 * @param demoMap
	 * @return
	 */
	@Override
	public Map<String, Object> demoCode(Map<String, String> demoMap) {
		/* 1. 將前端傳入值取出：使用前端傳入物件的key值，從Map中取得對應value，例如： */
		String id = demoMap.get("id");
		String keyword = demoMap.get("keyword");
		System.err.println("id--->" + id);
		System.err.println("keyword--->" + keyword);

		/*
		 * 2. 業務邏輯：檢核、題目要求邏輯實作，如需使用DB連線，請參考下列程式碼 try (Connection conn =
		 * dataSource.getConnection(); PreparedStatement pstmt =
		 * conn.prepareStatement(DEMOCODE_QUERY_SQL_STRING);) {
		 * 
		 * 
		 * } catch (SQLException e) { e.printStackTrace(); }
		 */

		/* 3. 把要回傳給前端的值包裝成Map後return，例如： */
		Map<String, Object> rtnMap = new HashMap<>();
		rtnMap.put("success", true);
		rtnMap.put("returnMessage", "驗證成功");
		rtnMap.put("metro_fee", 100);
		rtnMap.put("pokerA", new ArrayList<>());
		return rtnMap;
	}

	@Override
	public Map<String, Object> deal(Map<String, String> map) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Map<String, Object> checkId(Map<String, String> map) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Map<String, Object> getRandomId(Map<String, String> map) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Map<String, Object> wordle(Map<String, String> map) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Map<String, Object> metro(Map<String, String> map) {
		// TODO Auto-generated method stub
		return null;
	}
}
